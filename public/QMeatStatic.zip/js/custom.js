'use strict'
$( document ).ready(function() {
    console.log( "Hello!" );
});
